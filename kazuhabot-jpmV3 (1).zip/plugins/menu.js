import os from "os"

function runtime(seconds) {
    seconds = Number(seconds)
    const d = Math.floor(seconds / (3600 * 24))
    const h = Math.floor(seconds % (3600 * 24) / 3600)
    const m = Math.floor(seconds % 3600 / 60)
    const s = Math.floor(seconds % 60)
    return `${d}d ${h}h ${m}m ${s}s`
}

export default async function menu(sock, sender, command, key, messageEvent) {

    const linkGroup = "https://whatsapp.com/channel/0029Vb6XrxpE50UhO8Scch3I"
    const thumbUrl = "https://files.catbox.moe/5ac4g1.jpg"

    const groups = await sock.groupFetchAllParticipating()
    const totalGroups = Object.keys(groups).length

    const autoJpm = global.autojpmRunning ? "🟢 ACTIVE" : "🔴 INACTIVE"
    const autoJpmTag = global.autojpmtagRunning ? "🟢 ACTIVE" : "🔴 INACTIVE"
    const autoSwgc = global.autoswgcRunning ? "🟢 ACTIVE" : "🔴 INACTIVE"

    const readMore = String.fromCharCode(8206).repeat(4001)

    const teks = `
╔══════════════════════════════╗
        🍁  KAZUHABOT  🍁
   Maple Broadcast System 3.0.0
╚══════════════════════════════╝

👤 User        : ${sender.split("@")[0]}
👑 Owner       : kazuha🍁
📦 Script Name : kazuhabot-jpm🍁
👥 Total Group : ${totalGroups}
🖥 Platform    : ${os.platform()}
⏳ Runtime     : ${runtime(process.uptime())}

━━━━━━━━━━━━━━━━━━━━━━━━━━

🤖 AUTO SYSTEM STATUS
━━━━━━━━━━━━━━━━━━━━━━━━━━
• Auto JPM      : ${autoJpm}
• Auto JPM Tag  : ${autoJpmTag}
• Auto SWGC     : ${autoSwgc}

━━━━━━━━━━━━━━━━━━━━━━━━━━
${readMore}

📢 BROADCAST CONTROL
━━━━━━━━━━━━━━━━━━━━━━━━━━
• .jpm
• .jpmtag
• .autojpm
• .autojpmtag
• .stopautojpm
• .stopautojpmtag

📣 STATUS GROUP SYSTEM
━━━━━━━━━━━━━━━━━━━━━━━━━━
• .swgc
• .autoswgc
• .stopswgc
• .stopautoswgc

👥 GROUP MANAGEMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━
• .join
• .joinall
• .gasjoin
• .stopjoinall
• .cekjoin
• .listgc

⚙ UTILITIES
━━━━━━━━━━━━━━━━━━━━━━━━━━
• .pushkontak
• .autoreply
• .ping
• .menu

━━━━━━━━━━━━━━━━━━━━━━━━━━
🍁 Powered By kazuhabot-jpm
`

    await sock.sendMessage(
        sender,
        {
            text: teks,
            contextInfo: {
                externalAdReply: {
                    title: "Kazuhabot-Jpm V3.0🍁",
                    body: "Maple Broadcast System",
                    thumbnailUrl: thumbUrl,
                    sourceUrl: linkGroup,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: false
                }
            }
        },
        { quoted: messageEvent.messages[0] }
    )
}