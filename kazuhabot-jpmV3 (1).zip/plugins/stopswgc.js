export default async function stopswgc(sock, sender) {

    if (!global.swgcData) {
        return sock.sendMessage(sender, {
            text: "❌ SWGC tidak sedang berjalan."
        });
    }

    global.swgcStop = true;

    let terkirim = global.swgcData.sent;
    let total = global.swgcData.total;
    let sisa = total - terkirim;
    let durasi = Date.now() - global.swgcData.startTime;

    return sock.sendMessage(sender, {
        text:
`🍁 *SWGC DIHENTIKAN*

📢 Total   : ${total}
✅ Terkirim: ${terkirim}
📦 Sisa    : ${sisa}
⏱ Waktu    : ${Math.floor(durasi/1000)} detik

Proses berhasil dihentikan.`
    });
}