import clc from "cli-color"
import { readWhitelist } from "../lib/utils.js"

if (global.autojpmRunning === undefined) {
    global.autojpmRunning = false
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms))

async function getAllGroups(sock) {
    try {
        const groups = await sock.groupFetchAllParticipating()
        return Object.values(groups)
    } catch {
        return []
    }
}

function logAuto(feature, current, total, groupName) {
    const time = new Date().toLocaleTimeString()
    console.log(
        `[${time}] 🍁 ${feature} | ${current}/${total} | ${groupName}`
    )
}

export default async function autojpm(sock, sender, messages) {

    const parts = messages.trim().split(" ")
    if (parts.length < 3)
        return sock.sendMessage(sender, { text: "Format: .autojpm <menit> <pesan>" })

    const intervalMenit = parseInt(parts[1])
    const text = parts.slice(2).join(" ")

    if (global.autojpmRunning)
        return sock.sendMessage(sender, { text: "🍁 AutoJPM sudah berjalan." })

    global.autojpmRunning = true
    let cycle = 0

    while (global.autojpmRunning) {

        cycle++

        const allGroups = await getAllGroups(sock)
        const whitelist = readWhitelist()
        const target = whitelist
            ? allGroups.filter(g => !whitelist.includes(g.id))
            : allGroups

        const totalGroups = target.length
        const delayPerGroup = 20000
        const estimasiDetik = Math.floor((totalGroups * delayPerGroup) / 1000)
        const menit = Math.floor(estimasiDetik / 60)
        const detik = estimasiDetik % 60

        await sock.sendMessage(sender, {
            text: `🍁 AUTO JPM PUTARAN #${cycle}

• Total Grup : ${totalGroups}
• Delay      : 20 detik / grup
• Estimasi   : ${menit} menit ${detik} detik
• Status     : Running`
        })

        let count = 0

        for (const group of target) {

            if (!global.autojpmRunning) break

            count++

            try {
                await sock.sendMessage(group.id, { text })
                logAuto("AUTO JPM", count, totalGroups, group.subject)
            } catch {}

            await sleep(delayPerGroup)
        }

        await sock.sendMessage(sender, {
            text: `🍁 AUTO JPM PUTARAN #${cycle} SELESAI

• Berhasil kirim ke ${count} grup
• Menunggu ${intervalMenit} menit...`
        })

        await sleep(intervalMenit * 60000)
    }

    console.log("🍁 AUTO JPM STOP")
}