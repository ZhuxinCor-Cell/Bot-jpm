export default async function stopautojpm(sock, sender) {

    if (!global.autojpmRunning)
        return sock.sendMessage(sender, { text: "🍁 AutoJPM tidak sedang berjalan." })

    global.autojpmRunning = false

    await sock.sendMessage(sender, {
        text: `🍁 AUTO JPM DIHENTIKAN

• Status : Nonaktif
• Waktu  : ${new Date().toLocaleTimeString()}`
    })
}