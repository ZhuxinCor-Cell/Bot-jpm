import clc from 'cli-color';
import fs from 'fs';
import { downloadAndSaveMedia, readWhitelist } from '../lib/utils.js';

if (!global.botState) {
    global.botState = { jpmRunning: false };
}

if (!global.jpmProgress) {
    global.jpmProgress = { total: 0, sent: 0 };
}

if (global.jpmStop === undefined) {
    global.jpmStop = false;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function formatDuration(ms) {
    let totalSeconds = Math.floor(ms / 1000);
    let hours = Math.floor(totalSeconds / 3600);
    let minutes = Math.floor((totalSeconds % 3600) / 60);
    let seconds = totalSeconds % 60;

    return `${hours > 0 ? hours + " jam " : ""}${minutes} menit ${seconds} detik`;
}

async function getAllGroups(sock) {
    try {
        const groups = await sock.groupFetchAllParticipating();
        return Object.values(groups).map(group => ({
            id: group.id,
            name: group.subject
        }));
    } catch (error) {
        console.error(clc.red("🍁 ERROR ambil grup:"), error);
        return [];
    }
}

async function jpm(sock, sender, messages, key, messageEvent) {

    if (global.botState.jpmRunning) return;
    global.botState.jpmRunning = true;

    const message = messageEvent.messages?.[0];
    const privateSender = message.key.participant || sender;

    if (!global.jeda) {
        global.botState.jpmRunning = false;
        return;
    }

    let imagePath = null;

    try {

        // === DETEKSI GAMBAR ===
        let quoted = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        let mime = quoted?.imageMessage?.mimetype || message?.message?.imageMessage?.mimetype;

        if (mime && mime.includes("image")) {
            const mediaMessage = quoted?.imageMessage ? { message: quoted } : message;
            const filename = `${privateSender}.jpeg`;
            const result = await downloadAndSaveMedia(sock, mediaMessage, filename);
            if (result) imagePath = `./tmp/${filename}`;
        }

        const parts = messages.trim().split(' ');
        if (parts.length < 2) {
            return sock.sendMessage(privateSender, {
                text:
`🍁 *JPM - Broadcast Grup*

Cara pakai:
.jpm <pesan>

Contoh:
.jpm Halo semuanya`
            });
        }

        const text = parts.slice(1).join(' ');
        if (!text) {
            return sock.sendMessage(privateSender, {
                text: "🍁 Pesan tidak boleh kosong."
            });
        }

        const allGroups = await getAllGroups(sock);
        if (!allGroups.length) {
            return sock.sendMessage(privateSender, {
                text: "🍁 Bot tidak berada di grup mana pun."
            });
        }

        const whitelist = readWhitelist();
        const targetGroups = whitelist
            ? allGroups.filter(group => !whitelist.includes(group.id))
            : allGroups;

        if (targetGroups.length === 0) {
            return sock.sendMessage(privateSender, {
                text: "🍁 Semua grup berada dalam whitelist."
            });
        }

        // === SET PROGRESS ===
        global.jpmProgress.total = targetGroups.length;
        global.jpmProgress.sent = 0;

        const estimatedTime = targetGroups.length * global.jeda;

        await sock.sendMessage(privateSender, {
            text:
`🍁 *JPM TELAH DIMULAI*

📢 Target Grup : ${targetGroups.length}
⏳ Delay       : ${global.jeda} ms
⏱ Estimasi     : ${formatDuration(estimatedTime)}

Mohon tunggu sampai selesai...`
        });

        for (const group of targetGroups) {

            if (global.jpmStop) {
                await sock.sendMessage(privateSender, {
                    text:
`🍁 *JPM DIHENTIKAN*

📊 Terkirim : ${global.jpmProgress.sent}
🎯 Total    : ${global.jpmProgress.total}`
                });

                global.jpmStop = false;
                break;
            }

            try {

                await sock.sendMessage(
                    group.id,
                    imagePath
                        ? { image: fs.readFileSync(imagePath), caption: text }
                        : { text }
                );

                global.jpmProgress.sent++;

                let percent = Math.floor(
                    (global.jpmProgress.sent / global.jpmProgress.total) * 100
                );

                console.log(
                    clc.cyan(`🍁 [${global.jpmProgress.sent}/${global.jpmProgress.total} | ${percent}%]`) +
                    " " +
                    clc.green("BERHASIL") +
                    " -> " +
                    clc.white(group.name)
                );

            } catch (error) {

                console.log(
                    clc.cyan(`🍁 [${global.jpmProgress.sent + 1}/${global.jpmProgress.total}]`) +
                    " " +
                    clc.red("GAGAL") +
                    " -> " +
                    clc.white(group.name)
                );
            }

            for (let i = 0; i < global.jeda; i += 1000) {

                if (global.jpmStop) break;
                await sleep(1000);
            }
        }

        if (!global.jpmStop) {
            await sock.sendMessage(privateSender, {
                text:
`🍁 *JPM SELESAI*

✅ Berhasil dikirim ke ${global.jpmProgress.sent} grup.`
            });
        }

    } catch (err) {
        console.error(clc.red("🍁 FATAL ERROR JPM:"), err);
    } finally {

        if (imagePath && fs.existsSync(imagePath)) {
            fs.unlinkSync(imagePath);
        }

        global.botState.jpmRunning = false;
    }
}

export default jpm;