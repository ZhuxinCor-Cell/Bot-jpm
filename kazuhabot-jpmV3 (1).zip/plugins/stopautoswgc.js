export default async function stopautoswgc(sock, sender) {

    if (!global.autoswgcRunning)
        return sock.sendMessage(sender, { text: "🍁 AutoSWGC tidak sedang berjalan." })

    global.autoswgcRunning = false

    await sock.sendMessage(sender, {
        text: `🍁 AUTO SWGC DIHENTIKAN

• Status : Nonaktif
• Waktu  : ${new Date().toLocaleTimeString()}`
    })
}