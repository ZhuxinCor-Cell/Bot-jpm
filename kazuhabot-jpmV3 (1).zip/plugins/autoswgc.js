import { groupStatus } from "../lib/groupStatus.js"

if (global.autoswgcRunning === undefined) {
    global.autoswgcRunning = false
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms))

async function getAllGroups(sock) {
    try {
        const groups = await sock.groupFetchAllParticipating()
        return Object.values(groups)
    } catch {
        return []
    }
}

export default async function autoswgc(sock, sender, messages) {

    const parts = messages.trim().split(" ")
    if (parts.length < 3)
        return sock.sendMessage(sender, { text: "Format: .autoswgc <menit> <pesan>" })

    const intervalMenit = parseInt(parts[1])
    const text = parts.slice(2).join(" ")

    if (global.autoswgcRunning)
        return sock.sendMessage(sender, { text: "🍁 AutoSWGC sudah berjalan." })

    global.autoswgcRunning = true
    let cycle = 0

    while (global.autoswgcRunning) {

        cycle++

        const groups = await getAllGroups(sock)
        const totalGroups = groups.length
        const delayPerGroup = 20000

        await sock.sendMessage(sender, {
            text: `🍁 AUTO SWGC PUTARAN #${cycle}

• Total Grup : ${totalGroups}
• Status     : Running`
        })

        let count = 0

        for (const group of groups) {

            if (!global.autoswgcRunning) break

            count++

            try {
                await groupStatus(sock, group.id, { text })
                console.log(`🍁 AUTO SWGC | ${count}/${totalGroups} | ${group.subject}`)
            } catch {}

            await sleep(delayPerGroup)
        }

        await sock.sendMessage(sender, {
            text: `🍁 AUTO SWGC PUTARAN #${cycle} SELESAI

• Berhasil kirim ke ${count} grup
• Menunggu ${intervalMenit} menit...`
        })

        await sleep(intervalMenit * 60000)
    }

    console.log("🍁 AUTO SWGC STOP")
}