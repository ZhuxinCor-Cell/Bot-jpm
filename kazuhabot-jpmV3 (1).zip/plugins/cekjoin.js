export default async function cekjoin(sock, sender) {

    if (!global.joinProgress || !global.joinProgress[sender]) {
        return sock.sendMessage(sender, {
            text: "❌ Tidak ada proses join yang sedang berjalan."
        });
    }

    const data = global.joinProgress[sender];

    const selesai = data.sukses + data.gagal;
    const sisa = data.total - selesai;
    const percent = Math.floor((selesai / data.total) * 100);

    await sock.sendMessage(sender, {
        text: `
╭━━━━━━━━━━━━━━━━━━━🍁
┃ 📊 PROGRESS JOIN
┃
┃ 📦 Total   : ${data.total}
┃ ✔️ Sukses  : ${data.sukses}
┃ ❌ Gagal   : ${data.gagal}
┃ ⏳ Sisa    : ${sisa}
┃ 📈 Progress: ${percent}%
╰━━━━━━━━━━━━━━━━━━━🍁
`
    });
}