function formatDuration(ms) {
    let totalSeconds = Math.floor(ms / 1000);
    let minutes = Math.floor(totalSeconds / 60);
    let seconds = totalSeconds % 60;
    return `${minutes} menit ${seconds} detik`;
}

export default async function (sock, sender) {

    try {

        if (!global.pendingJoin || !global.pendingJoin[sender]) {
            return sock.sendMessage(sender, {
                text: "❌ Tidak ada data join tersimpan."
            })
        }

        const links = global.pendingJoin[sender]

        // ✅ buat tracker progress
        global.joinProgress = global.joinProgress || {}
        global.joinProgress[sender] = {
            total: links.length,
            sukses: 0,
            gagal: 0
        }

        const estimatedTime = links.length * global.jeda

        await sock.sendMessage(sender, {
            text: `
╭━━━━━━━━━━━━━━━━━━━🍁
┃ 🚀 JOIN DIMULAI
┃
┃ 📦 Total Grup : ${links.length}
┃ ⏳ Delay Auto : ${global.jeda / 1000} detik
┃ ⏱ Estimasi : ${formatDuration(estimatedTime)}
╰━━━━━━━━━━━━━━━━━━━🍁
`
        })

        for (let link of links) {

            // 🛑 cek stop
            if (!global.pendingJoin[sender]) {

                const data = global.joinProgress[sender]

                await sock.sendMessage(sender, {
                    text: `
╭━━━━━━━━━━━━━━━━━━━🍁
┃ 🛑 JOIN DIHENTIKAN
┃
┃ 📦 Total : ${data.total}
┃ ✔️ Sukses : ${data.sukses}
┃ ❌ Gagal : ${data.gagal}
┃ ⏹️ Sisa : ${data.total - (data.sukses + data.gagal)}
╰━━━━━━━━━━━━━━━━━━━🍁
`
                })

                delete global.joinProgress[sender]
                return
            }

            try {
                const code = link.split("chat.whatsapp.com/")[1]
                await sock.groupAcceptInvite(code)
                global.joinProgress[sender].sukses++
            } catch {
                global.joinProgress[sender].gagal++
            }

            await new Promise(resolve => setTimeout(resolve, global.jeda))
        }

        const data = global.joinProgress[sender]

        delete global.pendingJoin[sender]
        delete global.joinProgress[sender]

        await sock.sendMessage(sender, {
            text: `
╭━━━━━━━━━━━━━━━━━━━🍁
┃ ✅ JOIN SELESAI
┃
┃ 📦 Total : ${data.total}
┃ ✔️ Sukses : ${data.sukses}
┃ ❌ Gagal : ${data.gagal}
╰━━━━━━━━━━━━━━━━━━━🍁
`
        })

    } catch (err) {
        console.log("ERROR GASJOIN:", err)
    }
}