export default async function (sock, sender) {

    if (!global.pendingJoin || !global.pendingJoin[sender]) {
        return sock.sendMessage(sender, {
            text: "❌ Tidak ada proses join berjalan."
        })
    }

    const data = global.joinProgress?.[sender]

    delete global.pendingJoin[sender]

    if (!data) {
        return sock.sendMessage(sender, {
            text: "🛑 JoinAll dihentikan."
        })
    }

    await sock.sendMessage(sender, {
        text: `
╭━━━━━━━━━━━━━━━━━━━🍁
┃ 🛑 JOIN DIHENTIKAN
┃
┃ 📦 Total : ${data.total}
┃ ✔️ Sukses : ${data.sukses}
┃ ❌ Gagal : ${data.gagal}
┃ ⏹️ Sisa : ${data.total - (data.sukses + data.gagal)}
╰━━━━━━━━━━━━━━━━━━━🍁
`
    })
}