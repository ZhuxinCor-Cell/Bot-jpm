import clc from "cli-color"

if (global.autojpmtagRunning === undefined) {
    global.autojpmtagRunning = false
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms))

async function getAllGroups(sock) {
    try {
        const groups = await sock.groupFetchAllParticipating()
        return Object.values(groups)
    } catch {
        return []
    }
}

export default async function autojpmtag(sock, sender, messages) {

    const parts = messages.trim().split(" ")
    if (parts.length < 3)
        return sock.sendMessage(sender, { text: "Format: .autojpmtag <menit> <pesan>" })

    const intervalMenit = parseInt(parts[1])
    const text = parts.slice(2).join(" ")

    if (global.autojpmtagRunning)
        return sock.sendMessage(sender, { text: "🍁 AutoJPMTag sudah berjalan." })

    global.autojpmtagRunning = true
    let cycle = 0

    while (global.autojpmtagRunning) {

        cycle++

        const groups = await getAllGroups(sock)
        const totalGroups = groups.length
        const delayPerGroup = 25000

        await sock.sendMessage(sender, {
            text: `🍁 AUTO JPM TAG PUTARAN #${cycle}

• Total Grup : ${totalGroups}
• Mode       : Mention All
• Status     : Running`
        })

        let count = 0

        for (const group of groups) {

            if (!global.autojpmtagRunning) break

            count++

            try {
                const meta = await sock.groupMetadata(group.id)
                const members = meta.participants.map(p => p.id)

                await sock.sendMessage(group.id, {
                    text,
                    mentions: members
                })

                console.log(`🍁 AUTO JPM TAG | ${count}/${totalGroups} | ${group.subject}`)
            } catch {}

            await sleep(delayPerGroup)
        }

        await sock.sendMessage(sender, {
            text: `🍁 AUTO JPM TAG PUTARAN #${cycle} SELESAI

• Berhasil kirim ke ${count} grup
• Menunggu ${intervalMenit} menit...`
        })

        await sleep(intervalMenit * 60000)
    }

    console.log("🍁 AUTO JPM TAG STOP")
}