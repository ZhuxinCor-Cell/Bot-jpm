import fs from 'fs';
import clc from 'cli-color';
import { groupStatus } from '../lib/groupStatus.js';
import { isImageMessage, downloadAndSaveMedia } from '../lib/utils.js';

if (global.swgcStop === undefined) global.swgcStop = false;
if (global.swgcData === undefined) global.swgcData = null;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function formatTime(ms) {
    let totalSec = Math.floor(ms / 1000);
    let menit = Math.floor(totalSec / 60);
    let detik = totalSec % 60;
    return `${menit} menit ${detik} detik`;
}

async function getAllGroups(sock) {
    const groups = await sock.groupFetchAllParticipating();
    return Object.values(groups);
}

export default async function swgc(sock, sender, messages, key, messageEvent) {

    const message = messageEvent.messages?.[0];
    let imagePath = null;

    if (isImageMessage(messageEvent)) {
        const filename = `${sender}_swgc.jpeg`;
        const result = await downloadAndSaveMedia(sock, message, filename);
        if (result) imagePath = `./tmp/${filename}`;
    }

    const parts = messages.trim().split(' ');
    if (parts.length < 2 && !imagePath) {
        return sock.sendMessage(sender, {
            text:
`🍁 *SWGC - Status Grup*

Cara pakai:
.swgc <pesan>

Atau kirim gambar + caption:
.swgc caption`
        });
    }

    const text = parts.slice(1).join(' ');
    const groups = await getAllGroups(sock);

    let total = groups.length;
    let delay = global.jeda || 5000;
    let estimasi = total * delay;

    global.swgcData = {
        total,
        sent: 0,
        startTime: Date.now(),
        delay
    };

    await sock.sendMessage(sender, {
        text:
`🍁 *SWGC DIMULAI*

📢 Total Grup : ${total}
⏳ Delay       : ${delay} ms
⏱ Estimasi     : ${formatTime(estimasi)}

Mohon tunggu sampai selesai...`
    });

    for (const group of groups) {

        if (global.swgcStop) break;

        const payload = imagePath
            ? { image: fs.readFileSync(imagePath), caption: text }
            : { text };

        const result = await groupStatus(sock, group.id, payload);

        if (result) {
    global.swgcData.sent++;

    let sent = global.swgcData.sent;
    let total = global.swgcData.total;
    let percent = Math.floor((sent / total) * 100);

    let barLength = 24;
    let filled = Math.floor((percent / 100) * barLength);
    let empty = barLength - filled;
    let progressBar = "█".repeat(filled) + "░".repeat(empty);

    let elapsed = Date.now() - global.swgcData.startTime;
    let speed = (sent / (elapsed / 60000)).toFixed(2);

    process.stdout.write('\x1Bc');

    let titleColor = percent > 80 ? clc.redBright :
                     percent > 50 ? clc.yellowBright :
                     clc.greenBright;

    console.log(titleColor("🍁 SWGC PREMIUM CONSOLE"));
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log(clc.cyan(`📦 Progress : ${sent}/${total} (${percent}%)`));
    console.log(clc.yellow(`📊 [${progressBar}]`));
    console.log(clc.blueBright(`⚡ Speed : ${speed} grup/menit`));
    console.log(clc.white(`📍 Grup terakhir : ${group.subject}`));
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
}

        for (let i = 0; i < delay; i += 1000) {
            if (global.swgcStop) break;
            await sleep(1000);
        }
    }

    if (!global.swgcStop) {

        let durasi = Date.now() - global.swgcData.startTime;

        await sock.sendMessage(sender, {
            text:
`🍁 *SWGC SELESAI*

✅ Terkirim : ${global.swgcData.sent}
⏱ Waktu    : ${formatTime(durasi)}`
        });
    }

    global.swgcStop = false;
    global.swgcData = null;

    if (imagePath && fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
    }
}