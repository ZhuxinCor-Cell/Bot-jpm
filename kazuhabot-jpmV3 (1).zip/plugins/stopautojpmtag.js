export default async function stopautojpmtag(sock, sender) {

    if (!global.autojpmtagRunning)
        return sock.sendMessage(sender, { text: "🍁 AutoJPMTag tidak sedang berjalan." })

    global.autojpmtagRunning = false

    await sock.sendMessage(sender, {
        text: `🍁 AUTO JPM TAG DIHENTIKAN

• Status : Nonaktif
• Waktu  : ${new Date().toLocaleTimeString()}`
    })
}