export default async function stopjpm(sock, sender) {

    if (!global.botState?.jpmRunning) return;

    global.jpmStop = true;

    return sock.sendMessage(sender, {
        text:
`🍁 *PERINTAH STOP DITERIMA*

Menunggu proses berhenti...`
    });
}