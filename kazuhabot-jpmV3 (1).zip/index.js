/*
╔══════════════════════════════════════════════╗
║              🍁 LUCIFERNIGHT-MD  SYSTEM 🍁          ║
╠══════════════════════════════════════════════╣
║ 🤖 Bot Name   : ℒ𝒖𝒄𝒊𝒇𝒆𝒓𝑵𝒊𝒈𝒉𝒕-MD                    ║
║ 📦 Version    : 3.0.0                        ║
║ 👑 Owner      : ℒ𝒖𝒄𝒊𝒇𝒆𝒓𝑵𝒊𝒈𝒉𝒕𝑺𝒊𝒙𝒕𝒓𝒚🕊️                     ║
║ 🌐 Channel    : https://whatsapp.com/channel/0029Vb8XeW56hENtEztaWL37
╚══════════════════════════════════════════════╝
*/

console.log('Start App ..')


import fs from "fs";
import path from "path";
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} from "baileys";
import { Boom } from "@hapi/boom";
import P from "pino";
import qrcode from "qrcode-terminal";
import readline from "readline";
import clc from "cli-color";
import crypto from "crypto";
import "./config.js";


import {
  deleteFolderRecursive,
  ChangeStatus,
  getStatus,
  handleCommand,
  displayTime,
  logWithTime
} from "./lib/utils.js";


import resumeAutoJPM from "./lib/resumeAutoJPM.js";

// Pengganti __dirname di ESM
import { fileURLToPath } from "url";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const basePath = __dirname;
const status = getStatus(`${basePath}/sessions/`);

const lockedHash = "807c0b09f51c09a9dabeda3ca6d105839dd70d6c0d80bd4e68842d77261361ca"

const check = crypto
  .createHash("sha256")
  .update(global.name_script)
  .digest("hex")

if (check !== lockedHash) {
  console.log("⚠ Script name telah diubah! Sistem dihentikan.")
  process.exit(1)
}

console.clear()

console.log(`
╔══════════════════════════════════════╗
║        🍁 KAZUHABOT SYSTEM 🍁        ║
╠══════════════════════════════════════╣
║ 🤖 Bot Name  : kazuhabot🍁           ║
║ 📦 Version   : 3.0.0                 ║
║ 👑 Owner     : kazuha🍁              ║
╚══════════════════════════════════════╝
`)

async function connectToWhatsApp(number = null) {
  try {
    const { state, saveCreds } = await useMultiFileAuthState("sessions");
    const { version } = await fetchLatestBaileysVersion();

   
    const sock = makeWASocket({
      version,
      auth: state,
      printQRInTerminal: false,
      connectTimeoutMs: 6000,
      logger: P({ level: "silent" }),
    });

    sock.ev.on("connection.update", (update) =>
      handleConnectionUpdate(sock, update, number)
    );
    sock.ev.on("messages.upsert", (message) =>
      handleIncomingMessages(sock, message)
    );
    sock.ev.on("creds.update", saveCreds);
  } catch (error) {
    logWithTime("Failed to connect to WhatsApp", "red");
  }
}

async function handleConnectionUpdate(sock, update, number) {
  const { connection, lastDisconnect, qr } = update;
  if (pairingMethod === "qr" && qr) {
    qrcode.generate(qr, { small: true });
    console.log(clc.red.bold("Please scan the QR code displayed above."));
  } else if (
    connection &&
    pairingMethod === "pairing" &&
    number &&
    !sock.authState.creds.registered
  ) {
    const phoneNumber = number.toString();
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    console.log(clc.yellow(`Meminta Code...`));
    await delay(3000);
    const code = await sock.requestPairingCode(phoneNumber.trim());
    const formattedCode = code.slice(0, 4) + "-" + code.slice(4);

    console.log(`${clc.green.bold("Code Pairing :")} ${formattedCode}`);
  }

  if (connection === "close") {
    const shouldReconnect =
      lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
    logWithTime("Connection Closed", "red");
    ChangeStatus(`${basePath}/sessions/`, "closed");
    if (shouldReconnect) {
      connectToWhatsApp();
    }
  } else if (connection === "open") {
    logWithTime("Connection Success", "green");
    ChangeStatus(`${basePath}/sessions/`, "connected");
    // Setelah sock siap:

    resumeAutoJPM(sock);
  }
}

async function handleIncomingMessages(sock, messageEvent) {
  try {
    const message = messageEvent.messages?.[0];
    if (!message) throw new Error("Message is undefined or empty");
    const type = messageEvent?.type ?? false;
    if (type && type == "append") {
      return false;
    }

    const isGroup = Boolean(message.key?.participant);
    const sender = message.key?.remoteJidAlt || message.key?.remoteJid;
    const key = message?.key;
    const senderNumber = (() => {
      if (isGroup) {
        const participant = message.key?.participantAlt || message.key?.participant;
        return participant ? participant.split("@")[0] : "unknown";
      } else {
        return sender ? sender.split("@")[0] : "unknown";
      }
    })();

    const fromMe = message.key?.fromMe ?? false;
    const status = message?.status ?? false;
    const textMessage =
      message.message?.extendedTextMessage?.text ||
      message.message?.conversation ||
      message.message?.imageMessage?.caption ||
      "";

    if (textMessage) {
      await handleCommand(
        sock,
        sender,
        textMessage.trim(),
        key,
        senderNumber,
        messageEvent,
        fromMe
      );
    }
  } catch (error) {
    console.log(
      clc.blue.underline(
        `[${displayTime()}] Failed to handle incoming message!`
      )
    );
  }
}

let pairingMethod = "";
if (status && status == "connected") {
  logWithTime("Connecting ...", "green");
  connectToWhatsApp();
} else {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  function flushOutput() {
    process.stdout.write("");
  }

  console.log(clc.blue.bold("Pilih metode koneksi (qr/pairing):"));
  flushOutput();
  deleteFolderRecursive(basePath, "sessions");
  rl.question("", (method) => {
    if (method === "qr" || method === "pairing") {
      pairingMethod = method;
      if (method === "pairing") {
        console.log(clc.blue.bold("Masukkan nomor telepon: :"));
        rl.question("", (number) => {
          connectToWhatsApp(number.trim());
          rl.close();
          return;
        });
      } else {
        connectToWhatsApp();
        rl.close();
        return;
      }
    } else {
      logWithTime('Metode koneksi tidak valid. Pilih "qr" atau "pairing".');
      rl.close();
      return;
    }
  });
}
