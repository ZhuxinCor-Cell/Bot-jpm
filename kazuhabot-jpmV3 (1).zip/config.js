/*
╔══════════════════════════════════════════════╗
║              🍁 LUCIFERNIGHT-MD SYSTEM 🍁          ║
╠══════════════════════════════════════════════╣
║ 🤖 Bot Name   : ℒ𝒖𝒄𝒊𝒇𝒆𝒓𝑵𝒊𝒈𝒉𝒕-MD                 ║
║ 📦 Version    : 3.0.0                        ║
║ 👑 Owner      : ℒ𝒖𝒄𝒊𝒇𝒆𝒓𝑵𝒊𝒈𝒉𝒕𝑺𝒊𝒙𝒕𝒓𝒚🕊️                     ║
║ 🌐 Channel    : https://whatsapp.com/channel/0029Vb8XeW56hENtEztaWL37
╚══════════════════════════════════════════════╝
*/
const numberAllowed = ["62833897955862"];//nomor lu,bukan nomor bot

global.prefix = [".", "#"];

global.jeda = 15000;

global.name_script = "ℒ𝒖𝒄𝒊𝒇𝒆𝒓𝑵𝒊𝒈𝒉𝒕𝑺𝒊𝒙𝒕𝒓𝒚🕊️";

global.version = "3.0";

global.autojpm = {
  hidetag: false,
  jedaPutaran: 10000,
};

export { numberAllowed };
